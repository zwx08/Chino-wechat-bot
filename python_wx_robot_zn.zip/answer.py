#默认为使用wxid作为userid，如果想要更改为使用单一userid请更改所有调用API_answer后的wxid改为userid

from action import *
#from another_action import _a_ , image, name_write,data_name_write,read_name_all,warn,w_all
from another_action import *
from answer_another import *
from answerAPI import *
from more_action import *
from another_action_wiki import wiki
import schedule
from sympy import *
from file_action import *


config=config_read()
address=config["connect"]["sent_address"]
port=config["connect"]["sent_port"]


number_of_times={}   #每10s清空一次number_of_times
def clear_number_of_times():
    number_of_times.clear()
schedule.every(10).minutes.do(clear_number_of_times)


def send_msg_an(an,wxid,wxid_group):        #允许传入列表，实现每次调用加一次number_of_times[wxid_group]，且如果这个数字超过指定数量后不回复
    if "an" in vars() and  'an' != None :
        print(an)

        if 'wxid_group' in locals():     
            if wxid_group in number_of_times:
                number_of_times[wxid_group] += 1
            else:
                number_of_times[wxid_group] = 1
            if number_of_times[wxid_group] > 5:
                return

        else:
            if wxid in number_of_times:
                number_of_times[wxid] += 1
            else:
                number_of_times[wxid] = 1
            if number_of_times[wxid] > 10:
                return
        if isinstance(an,(str,int)) ==True:
            an=call._a_(an,wxid,wxid_group,port) #特殊字符转换(_a_)
            sent_msg(port,wxid,an)
        else:
            for x in an:
                an=call._a_(an,wxid,wxid_group,port) #特殊字符转换(_a_)
                sent_msg(port,wxid,x)
    return


def answer(wxid,qu,wxid_group):  #主调用
    data=data_read()
    
    #admin部分
    an_admin = answer_admin(qu,wxid,wxid_group)
    if  an_admin != None:
        sent_msg(port,wxid,an_admin)
        return
    
    #黑白名单
    block=data["wxid_block"]
    white=data["wxid_white"]
    if (wxid and wxid_group)  in block:    #黑名单
        return
    if len(white) != 0: 
        if (wxid and wxid_group) not in white:   #白名单
            return

    #other部分
    an=answer_other(qu,wxid,wxid_group)
    if an != None :
        send_msg_an(an,wxid,wxid_group)
        return
    
    #answerAPI部分
    answer=API_answer(qu,wxid)
    if 'status' in answer:
        st=answer['status']
        if st == 'NOMATCH':
            if qu.find("智乃") != -1 and qu.find("~") != -1:
                an="_a_~"
        else:
            if 'answer' in answer :
                an=answer['answer']
    if 'options' in answer:
            options=answer['options']
            an=an+ '  :  ' + str(options)

    if "an" in vars() and  an != None :
        send_msg_an(an,wxid,wxid_group)
        return
