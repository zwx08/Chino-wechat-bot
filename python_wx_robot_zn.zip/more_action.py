import httpx
from file_action import *
import ujson

config=config_read()
address=config["connect"]["sent_address"]
port=config["connect"]["sent_port"]

def Request_nodata(way,api):
    return Request(way,api,None)
def Request(way,api,data):
    return Request_param1(way,api,data,None)
def Request_param1(way,api,data,param1):
    return Request_param2(way,api,data,param1,None)
def Request_param2(way,api,data,param1,param2):
    return Request_param3(way,api,data,param1,param2,None)
def Request_param3(way,api,data,param1,param2,param3):
    if param1 == None:
        apiurl=f"http://{address}:{port}/?api={api}"
    elif param2 == None:
        apiurl=f"http://{address}:{port}/?api={api}&param={param1}"
    elif param3 == None:
        apiurl=f"http://{address}:{port}/?api={api}&param1={param1}&param2={param2}"
    else:
        apiurl=f"http://{address}:{port}/?api={api}&param1={param1}&param2={param2}&param3={param3}"
    if way == "get":
        res_json = httpx.get(apiurl).text
    if way == "post":
        if data == None:
            res_json = httpx.post(apiurl)
        else:
            res_json = httpx.post(apiurl , json=data)
    #res=ujson.loads(res_json)
    print(res_json)
    return res_json

def get_original_picture(port,wxid,xml,image):   #测试未成功，不要用
    apiurl=f"http://{address}:{port}"
    data={"api": 1033,"xml":xml,"image":image}
    res = httpx.post(apiurl , json=data)
    print(res.text)


def get_original_picture_2(port,wxid,xml,image):  #测试未成功，不要用
    apiurl=f"http://{address}:{port}"
    data={"api": 1033,"xml":xml,"image":image}
    res = httpx.post(apiurl , json=data)
    print(res.text)

def update_group_member_details(port,wxid,wxid_group):
    return Request_param2("get",805,None,wxid,wxid_group)
def get_wxid_details(port,wxid):
    if len(wxid) != 0:
        apiurl=f"http://{address}:{port}/?api=4&param={wxid}"
    else:
        apiurl=f"http://{address}:{port}/?api=4"

    data={"api": 4}
    res_json = httpx.get(apiurl)
    res=res_json.json()
    print(res)
    return res

def get_chatroom_details_all(chatroom):
    return ujson.loads(Request_param1("get",552,None,chatroom))
