#此文件直接执行
#本例子只开启http端口接收，使用post方法
#此文件需answer.py

import ujson,json
from http.server import BaseHTTPRequestHandler, HTTPServer
from time import sleep
from action import *
from answer import *
from another_action import *
from file_action import *
import threading

config=config_read()
address=config["connect"]["rece_address"]
port=config["connect"]["rece_port"]  #信息接收端口
class myThread (threading.Thread):   # 继承父类threading.Thread
    def __init__(self,wxid,qu,wxid_group):
        threading.Thread.__init__(self)
        self.wxid = wxid
        self.qu = qu
        self.wxid_group = wxid_group
    def run(self):   # 把要执行的代码写到run函数里面 线程在创建后会直接运行run函数
        answer(self.wxid,self.qu,self.wxid_group)

class MyHTTPServer(BaseHTTPRequestHandler):
    def do_POST(self):
        data = self.rfile.read(int(self.headers['content-length']))  # 接收参数
        strs = str(data , encoding='utf-8')
        msg = ujson.loads(strs)  #此部分为消息接收端，这里将ujson转换为python字典
        #print(msg)            #调试用
        if msg['api'] == 1005:
            msg_data=msg["data"]    #1005消息主体
            qu=msg_data["StrContent"]   #消息内容
            wxid=msg_data["StrTalker"]  #消息发送人
            wxid_group=None
            print(qu)       #调试用
            print(wxid)     #调试用
            if '@chatroom' in wxid :
                byte=msg_data["BytesExtra"]
                wxid_group =byte['wxid']
                print(wxid_group)
            #sleep(0.1)
            if msg_data["IsSender"] == 0:     #判断是否是自己发的
                thread=myThread(wxid,qu,wxid_group)
                thread.setDaemon(True)
                thread.start()
                return
            


class server:
    def httpserver(self):
        server = HTTPServer((address , port) , MyHTTPServer)
        print(f"{server.server_address}servers启动成功")

        server.handle_request()
        server.serve_forever()

if __name__ == '__main__':
    a=server()
    a.httpserver()
