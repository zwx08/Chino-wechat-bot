from another_action import *
from file_action import *
from answerAPI import *
import wikipedia



def answer_admin(qu,wxid,wxid_group):
    data=data_read()
    wxid_admin=data["wxid_admin"]
    if wxid in wxid_admin or wxid_group in wxid_admin:
        if qu == '&m' :
            an_admin="不准骂人!"
        if qu =="&a":
            an_admin='不准聊天!'
        if qu =="&i":
            an_admin="不要在这个群发无关图片啊喂！"
        if qu =="&h":
            an_admin='涩涩，达咩'
        if qu =="&h1":
            an_admin='涩涩达咩!'
        if qu =="&ad":
            an_admin="广告达咩！"
        if qu=="&s":
            an_admin="刷屏警告！"

        if qu.find('/call') != -1:
            call.name_write(qu,wxid)
        if qu.find('/admin') != -1:
            an_admin=another_data_write.admin(qu)
        if qu.find('/block') != -1:
            an_admin=another_data_write.block(qu)
        if qu.find('/white') != -1:
            an_admin=another_data_write.white(qu)
        if qu.find("/warn") != -1:
            an_admin=warn.warn(qu,port,wxid)
        if qu.find("/w_alll") != -1:
            an_admin=warn.w_all_all()
        if qu.find("/w_del") != -1:
            an_admin=warn.w_del(qu,wxid)
        if qu.find("/ugmd") != -1:
            qu_data=qu.splitlines()
            update_group_member_details(port,wxid,qu_data[1])
            
        

        if qu == '^1':
            an_admin=API_release()
        if qu.find('^m') == 0:
            an_admin=API_Import(qu)

    if "an_admin" in vars():
        return an_admin
    













def answer_other(qu,wxid,wxid_group):
    key_word_suijitupian={"智乃随便来个二次元吧","智乃来个图","来个二次元小姐姐","智乃随便来个二次元","智乃来张图"}
    if qu in key_word_suijitupian :  #随机图片关键词
        an=image()

    

    struct_times = time.localtime(time.time())
    morning=(struct_times.tm_hour) >= 0 and (struct_times.tm_hour) < 12
    afternoon=(struct_times.tm_hour) >= 12 and (struct_times.tm_hour) < 18
    noon=(struct_times.tm_hour) >= 11 and (struct_times.tm_hour) <= 14
    night=(struct_times.tm_hour) >= 16 and (struct_times.tm_hour) < 24
    night_morn=(struct_times.tm_hour) >= 0 and (struct_times.tm_hour) < 6
    if morning:
        ti="早上"
    if afternoon:
        ti="下午"
    if night:
        ti="晚上"
    if night_morn:
        ti="凌晨"
    if noon:
        ti="中午"


    if qu.find("智乃") != -1:
        if qu.find("晚安") != -1:
            an="_a_晚安~"
        if qu.find("早安") != -1:
            an="_a_早安~"
        if qu.find("午安") != -1:
            an="_a_午安~"


        if qu.find("好") != -1:
            
            if qu.find("上午") != -1:
                if morning:
                    an="_a_上午好~"
                else:
                    an="啊喂！都"+ti+"了呢~"
            if qu.find("早上") != -1:
                if morning:
                    an="_a_早上好~"
                elif afternoon:
                    an="啊喂！都下午了呢~"
                else:
                    an="啊喂！都"+ti+"了呢~"
            if qu.find("下午") != -1:
                if afternoon:
                    an="_a_下午好~"
                else:
                    an="啊喂！都"+ti+"了呢~"
            if qu.find("中午") != -1:
                if noon:
                    an="_a_中午好~"
                else:
                    an="啊喂！都"+ti+"了呢~"
            if qu.find("晚上") != -1:
                if night:
                    an="_a_晚上好~"
                elif night_morn:
                    an="都早上了吧~"
                else:
                    an="啊喂！都"+ti+"了呢~"

    if (qu.find("早呀") != -1 and qu.find("各位") != -1) or qu.find("大家早") != -1:
        an="_a_早~"



    if qu =='/c_all':
        an=str(call.read_name_all())
    if qu.find("/userinfo") != -1:
        userinfo_wxid=qu.splitlines()
        sent_msg(port,wxid,str(get_wxid_details(port,userinfo_wxid[1])))
    if qu =="/w_all":
        an=warn.w_all(wxid)

    if qu.find("$ip") != -1:
        if len(qu) <= 4:
            an = httpx.get('https://checkip.amazonaws.com').text.strip()
        else:
            an = getting_ip(qu[4:])
    if qu.find("$wiki") != -1:
        wikipedia.set_lang("zh")
        an = wikipedia.summary(qu[6:], sentences=1)
    if qu.find("$c") != -1:
        calc = qu[3:]
        try:
            if calc.find("s") != -1:
                data=data_read()
                if wxid in (data["ca_save"]):
                    calc=calc.replace("s",(data["ca_save"])[wxid])
                    an = str(solve(calc))
                    data_write("ca_save",wxid,an)
                else:
                    an="无缓存"
            else:
                an = str(eval(calc))
                data_write("ca_save",wxid,an)
        except:
            an="输入错误"
    if "an" in vars():
        return an
    



